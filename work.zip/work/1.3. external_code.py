import csv
import json
from collections import OrderedDict
from itertools import tee
from typing import Any, Callable, Generator, Iterable, Tuple, KeysView, Dict


def read_records(file_name: str) -> Generator[dict, None, None]:
    """ Read records from CSV file; ``mcc_code`` field is required """
    with open(file_name) as transactions_file:
        yield from map(
            make_converter(mcc_code=int),
            csv.DictReader(transactions_file, delimiter=';'),
        )


def make_converter(**types_mapping: Callable[[Any], Any]) -> Callable[[Dict[str, Any]], Dict[str, Any]]:
    def convert(record: Dict[str, Any]) -> Dict[str, Any]:
        """ Convert record fields to a specified type """
        return {**record, **{
            key: _convert(record[key])
            for key, _convert in types_mapping.items()
        }}
    return convert


def write_statistic(dict_statistic: dict):
    dict_statistic = dict(OrderedDict(sorted(dict_statistic.items(), key=lambda t: t[0][0])))
    total = sum([x for x in dict_statistic.values()])
    with open('transactions_statistic.txt', 'w') as f:
        # json.dump(dict_statistic, f, ensure_ascii=False, indent=4)
        f.write('Category statistic:\n')
        f.writelines((f'({cat}, {mcc}): {cnt}\n' for (cat, mcc), cnt in dict_statistic.items()))
        f.write(f'Общее количество транзакций: {total}')


def left_join_mcc_codes_to_transactions(
    transactions_records: str,
    mcc_codes_records: str,
) -> Generator[dict, None, None]:
    mcc_codes_records, mcc_codes_records_copy = tee(mcc_codes_records)

    mcc_codes_mapping = {
        mcc_codes_record['mcc_code']: mcc_codes_record['category_name']
        for mcc_codes_record in mcc_codes_records
    }

    mcc_codes_statistic = {
        (mcc_codes_record['category_name'], mcc_codes_record['mcc_code']): 0
        for mcc_codes_record in mcc_codes_records_copy
    }

    # filtering
    filter_list = ['перевод']
    transactions_records = filter(lambda record: all([y not in record['description'] for y in filter_list]),
                                  transactions_records)

    for transaction_record in transactions_records:
        transaction_mcc_code = transaction_record['mcc_code']
        mcc_codes_statistic[mcc_codes_mapping[transaction_mcc_code], transaction_mcc_code] += 1
        yield {**transaction_record, **dict(category=mcc_codes_mapping[transaction_mcc_code])}

    # sort and write statistic
    write_statistic(mcc_codes_statistic)


def main() -> None:
    enriched_transactions = left_join_mcc_codes_to_transactions(
        transactions_records=read_records('transactions.csv'),
        mcc_codes_records=read_records('mcc_codes.csv'),
    )
    enriched_transactions, header = infer_header(enriched_transactions)
    with open('enriched_transactions.csv', 'w') as enriched_transactions_file:
        writer = csv.DictWriter(enriched_transactions_file, header, delimiter=';')
        writer.writeheader()
        writer.writerows(enriched_transactions)


def infer_header(records: Iterable[dict]) -> Tuple[Iterable[dict], KeysView]:
    records, records_copy = tee(records)
    try:
        return records, next(records_copy).keys()
    except StopIteration:
        return records, dict().keys()


if __name__ == '__main__':
    main()
